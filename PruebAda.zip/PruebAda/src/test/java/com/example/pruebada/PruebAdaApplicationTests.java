package com.example.pruebada;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PruebAdaApplicationTests {

    @Test
    void contextLoads() {
    }

}
