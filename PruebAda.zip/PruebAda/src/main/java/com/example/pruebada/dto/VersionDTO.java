package com.example.pruebada.dto;

import com.example.pruebada.model.Version;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class VersionDTO {
    private Long id;
    private String version;
    private String versionDescription;
    private ApplicationDTO applicationDTO;

    public VersionDTO(Version versionP) {
        this.id = versionP.getId();
        this.version = versionP.getVersion();
        this.versionDescription = versionP.getVersionDescription();
        applicationDTO = new ApplicationDTO(versionP.getApp());
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getVersionDescription() {
        return versionDescription;
    }

    public void setVersionDescription(String versionDescription) {
        this.versionDescription = versionDescription;
    }

    public ApplicationDTO getApplicationDTO() {
        return applicationDTO;
    }

    public void setApplicationDTO(ApplicationDTO applicationDTO) {
        this.applicationDTO = applicationDTO;
    }
}
