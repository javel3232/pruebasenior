package com.example.pruebada.dto;

import com.example.pruebada.model.Version;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CompanyInfoDTO {
    private String codigoCompany;
    private String nameCompany;
    private String appName;
    private String version;

    public CompanyInfoDTO(CompanyDTO companyDTO, VersionDTO versionDTO) {
        this.codigoCompany = companyDTO.getCodigoCompany();
        this.nameCompany = companyDTO.getNameCompany();
        this.appName = versionDTO.getApplicationDTO().getAppName();
        this.version = versionDTO.getVersion();
    }

    public String getCodigoCompany() {
        return codigoCompany;
    }

    public void setCodigoCompany(String codigoCompany) {
        this.codigoCompany = codigoCompany;
    }

    public String getNameCompany() {
        return nameCompany;
    }

    public void setNameCompany(String nameCompany) {
        this.nameCompany = nameCompany;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }
}
