package com.example.pruebada.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "company")
public class Company {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_company", nullable = false)
    private Long id;

    @Size(max = 50)
    @NotNull
    @Column(name = "codigo_company", nullable = false, length = 50)
    private String codigoCompany;

    @Size(max = 150)
    @NotNull
    @Column(name = "name_company", nullable = false, length = 150)
    private String nameCompany;

    @Size(max = 255)
    @Column(name = "description_company")
    private String descriptionCompany;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCodigoCompany() {
        return codigoCompany;
    }

    public void setCodigoCompany(String codigoCompany) {
        this.codigoCompany = codigoCompany;
    }

    public String getNameCompany() {
        return nameCompany;
    }

    public void setNameCompany(String nameCompany) {
        this.nameCompany = nameCompany;
    }

    public String getDescriptionCompany() {
        return descriptionCompany;
    }

    public void setDescriptionCompany(String descriptionCompany) {
        this.descriptionCompany = descriptionCompany;
    }

    public VersionCompany getVersionCompany() {
        return versionCompany;
    }

    public void setVersionCompany(VersionCompany versionCompany) {
        this.versionCompany = versionCompany;
    }

    @JsonIgnore
    @OneToOne(mappedBy = "company", cascade = CascadeType.REMOVE, orphanRemoval = true)
    private VersionCompany versionCompany;


}