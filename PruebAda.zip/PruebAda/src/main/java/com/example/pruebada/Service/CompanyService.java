package com.example.pruebada.Service;

import com.example.pruebada.dto.CompanyDTO;
import com.example.pruebada.dto.CompanyInfoDTO;
import org.springframework.data.crossstore.ChangeSetPersister;

import java.util.List;

public interface CompanyService {
    List<CompanyDTO> findAll();
    CompanyDTO findById(Long id) throws ChangeSetPersister.NotFoundException;
    CompanyDTO create(CompanyDTO dto);
    CompanyDTO update(Long id, CompanyDTO dto) throws ChangeSetPersister.NotFoundException;
    void delete(Long id) throws ChangeSetPersister.NotFoundException;
    CompanyInfoDTO findInfoByCodigo(String codigoCompany) throws ChangeSetPersister.NotFoundException;
}
