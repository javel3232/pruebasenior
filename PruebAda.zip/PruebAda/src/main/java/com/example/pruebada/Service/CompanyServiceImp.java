package com.example.pruebada.Service;

import com.example.pruebada.dto.CompanyDTO;
import com.example.pruebada.dto.CompanyInfoDTO;
import com.example.pruebada.dto.VersionDTO;
import com.example.pruebada.model.Company;
import com.example.pruebada.model.VersionCompany;
import com.example.pruebada.repository.CompanyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.crossstore.ChangeSetPersister;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CompanyServiceImp implements CompanyService{

    @Autowired
    private CompanyRepository companyRepository;


    public List<CompanyDTO> findAll() {
        return companyRepository.findAll().stream().map(CompanyDTO::new).toList();
    }

    public CompanyDTO findById(Long id) throws ChangeSetPersister.NotFoundException {
        Company c = companyRepository.findById(id)
                .orElseThrow(ChangeSetPersister.NotFoundException::new);
        return new CompanyDTO(c);
    }


    public CompanyDTO create(CompanyDTO dto) {
        Company c = new Company();
        c.setCodigoCompany(dto.getCodigoCompany());
        c.setNameCompany(dto.getNameCompany());
        c.setDescriptionCompany(dto.getDescriptionCompany());
        c = companyRepository.save(c);
        return new CompanyDTO(c);
    }


    public CompanyDTO update(Long id, CompanyDTO dto) throws ChangeSetPersister.NotFoundException {
        Company c = companyRepository.findById(id)
                .orElseThrow(ChangeSetPersister.NotFoundException::new);
        c.setCodigoCompany(dto.getCodigoCompany());
        c.setNameCompany(dto.getNameCompany());
        c.setDescriptionCompany(dto.getDescriptionCompany());
        return new CompanyDTO(companyRepository.save(c));
    }


    public void delete(Long id) throws ChangeSetPersister.NotFoundException {
        if (!companyRepository.existsById(id)) {
            throw new ChangeSetPersister.NotFoundException();
        }
        companyRepository.deleteById(id);
    }


    public CompanyInfoDTO findInfoByCodigo(String codigoCompany) throws ChangeSetPersister.NotFoundException {
        Company company = companyRepository.findByCodigoCompany(codigoCompany)
                .orElseThrow(ChangeSetPersister.NotFoundException::new);
        VersionCompany vc = company.getVersionCompany();
        if (vc == null || vc.getVersion() == null) {
            throw new ChangeSetPersister.NotFoundException();
        }
        CompanyDTO companyDTO = new CompanyDTO(company);
        VersionDTO versionDTO = new VersionDTO(vc.getVersion());

        return new CompanyInfoDTO(companyDTO, versionDTO);
    }

}
