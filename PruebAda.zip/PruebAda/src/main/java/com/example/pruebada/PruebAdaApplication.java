package com.example.pruebada;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PruebAdaApplication {

    public static void main(String[] args) {
        SpringApplication.run(PruebAdaApplication.class, args);
    }

}
