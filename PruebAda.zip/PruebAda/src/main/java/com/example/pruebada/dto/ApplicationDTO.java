package com.example.pruebada.dto;

import com.example.pruebada.model.Application;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ApplicationDTO {
    private Long id;
    private String appCode;
    private String appName;
    private String appDescription;

    public ApplicationDTO(Application applicationP) {
        this.id = applicationP.getId();
        this.appCode = applicationP.getAppCode();
        this.appName = applicationP.getAppName();
        this.appDescription = applicationP.getAppDescription();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getAppCode() {
        return appCode;
    }

    public void setAppCode(String appCode) {
        this.appCode = appCode;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getAppDescription() {
        return appDescription;
    }

    public void setAppDescription(String appDescription) {
        this.appDescription = appDescription;
    }
}
