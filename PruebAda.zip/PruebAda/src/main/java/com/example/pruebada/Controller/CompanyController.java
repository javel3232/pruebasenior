package com.example.pruebada.Controller;

import com.example.pruebada.Service.CompanyService;
import com.example.pruebada.dto.CompanyDTO;
import com.example.pruebada.dto.CompanyInfoDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.crossstore.ChangeSetPersister;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/companies")
public class CompanyController {

    @Autowired
    private CompanyService companyService;

    // CRUD
    @GetMapping
    public List<CompanyDTO> getAll() {
        return companyService.findAll();
    }

    @GetMapping("/{id}")
    public CompanyDTO getById(@PathVariable Long id) throws ChangeSetPersister.NotFoundException {
        return companyService.findById(id);
    }

    @PostMapping
    public CompanyDTO create(@RequestBody CompanyDTO dto) {
        return companyService.create(dto);
    }

    @PutMapping("/{id}")
    public CompanyDTO update(@PathVariable Long id, @RequestBody CompanyDTO dto) throws ChangeSetPersister.NotFoundException {
        return companyService.update(id, dto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) throws ChangeSetPersister.NotFoundException {
        companyService.delete(id);
        return ResponseEntity.noContent().build();
    }

    // GET especial: devuelve { codigo_company, name_company, app_name, version }
    @GetMapping("/info/{codigoCompany}")
    public CompanyInfoDTO getInfoByCodigo(@PathVariable String codigoCompany) throws ChangeSetPersister.NotFoundException {
        return companyService.findInfoByCodigo(codigoCompany);
    }
}
