package com.example.pruebada.dto;

import com.example.pruebada.model.Company;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CompanyDTO {

    private Long id;
    private String codigoCompany;
    private String nameCompany;
    private String descriptionCompany;

    public CompanyDTO(Company companyP) {
        this.id = companyP.getId();
        this.codigoCompany = companyP.getCodigoCompany();
        this.nameCompany = companyP.getNameCompany();
        this.descriptionCompany = companyP.getDescriptionCompany();

    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCodigoCompany() {
        return codigoCompany;
    }

    public void setCodigoCompany(String codigoCompany) {
        this.codigoCompany = codigoCompany;
    }

    public String getNameCompany() {
        return nameCompany;
    }

    public void setNameCompany(String nameCompany) {
        this.nameCompany = nameCompany;
    }

    public String getDescriptionCompany() {
        return descriptionCompany;
    }

    public void setDescriptionCompany(String descriptionCompany) {
        this.descriptionCompany = descriptionCompany;
    }




}
