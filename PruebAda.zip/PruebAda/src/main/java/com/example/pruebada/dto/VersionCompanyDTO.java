package com.example.pruebada.dto;

import com.example.pruebada.model.VersionCompany;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class VersionCompanyDTO {
    private Long id;
    private CompanyDTO companyDTO;
    private String versionCompanyDescription;


    public VersionCompanyDTO(VersionCompany versionCompanyP) {
        this.id = versionCompanyP.getId();
        this.companyDTO = new CompanyDTO(versionCompanyP.getCompany());
        this.versionCompanyDescription = versionCompanyP.getVersionCompanyDescription();

    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public CompanyDTO getCompanyDTO() {
        return companyDTO;
    }

    public void setCompanyDTO(CompanyDTO companyDTO) {
        this.companyDTO = companyDTO;
    }

    public String getVersionCompanyDescription() {
        return versionCompanyDescription;
    }

    public void setVersionCompanyDescription(String versionCompanyDescription) {
        this.versionCompanyDescription = versionCompanyDescription;
    }
}
