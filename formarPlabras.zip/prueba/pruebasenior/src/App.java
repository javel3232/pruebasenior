import java.util.List;

public class App {
    public static void main(String[] args) throws Exception {


        char[] letras = {
            'w','e','r','f','b','h','j','i','u','y','t','r','e','d','f','g','y','u','i','o',
            'l','k','m','n','b','v','f','r','e','w','s','x','f','g','y','u','i','k','m','n',
            'b','v','f','r','e','w','w','r','t','y','u','i','o','k','m','n','b','v','w','s',
            'x','c','f','g','h','u','i','o','p','l','k','n','b','v','f','d','e','w','a','z',
            'x','c','g','h','u','i','o','p','u','y','t','r','e','w','q','s','d','f','g','k',
            'j','v','c','x'
        };

        BolsaLetras bolsa = new BolsaLetras(letras);
        GneradorPalabras generador = new GneradorPalabras();

        System.out.println("Palabras válidas encontradas:");
        generador.generarPalabrasValidas(bolsa, Diccionario.PALABRAS)
                 .forEach(System.out::println);
        
    }

    /**
 * Tenemos una bolsa de letras y un listado de palabras que consideramos válidas.
 * Primero revisamos cuántas veces aparece cada letra en nuestra bolsa.
 * Después, vamos palabra por palabra comprobando si tenemos las letras necesarias
 * y en la cantidad justa para poder escribirla.
 * Si la palabra se puede formar la guardamos en la lista de resultados.
 * Así al final nos quedamos solo con las palabras que realmente podemos construir
 * con lo que tenemos a mano.
 */
}
