public class BolsaLetras {

    private char[] letras;

    public BolsaLetras(char[] letras) {
        this.letras = letras;
    }

    public char[] getLetras() {
        return letras;
    }

    public void setLetras(char[] letras) {
        this.letras = letras;
    }
    
}
