
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class GneradorPalabras {
    public List<String> generarPalabrasValidas(BolsaLetras bolsa, List<String> diccionario) { 
    Map<Character, Long> letrasDisponibles = contarFrecuencias(bolsa.getLetras());

 
    return diccionario.stream()
            .filter(palabra -> sePuedeFormar(palabra.toLowerCase(), letrasDisponibles))
            .sorted(Comparator.comparingInt(String::length).reversed())
            .toList();
}

private boolean sePuedeFormar(String palabra, Map<Character, Long> disponibles) { 
    for (char letra : palabra.toCharArray()) {
        long cantidadNecesaria = palabra.chars().filter(c -> c == letra).count();
        if (disponibles.getOrDefault(letra, 0L) < cantidadNecesaria) {
            return false;
        }
    }
    return true;
}

private Map<Character, Long> contarFrecuencias(char[] letras) {
    return new String(letras).chars()
            .mapToObj(c -> (char) c)
            .collect(Collectors.groupingBy(
                    Character::charValue,
                    Collectors.counting()
            ));
}

}
