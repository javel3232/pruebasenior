import java.util.List;

public class Diccionario {

     public static final List<String> PALABRAS = List.of(
        "web", "codigo", "java", "leer", "escribir", "programa",
        "perro", "gato", "casa", "raton", "hola", "mundo"
    );
    
}
