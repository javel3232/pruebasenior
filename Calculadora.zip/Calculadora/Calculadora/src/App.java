import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {

   Scanner sc = new Scanner(System.in);
        Calculadora calc = new Calculadora();
        ValidadorEntrada validador = new ValidadorEntrada();

        System.out.println("=== Calculadora ===");
        System.out.println("Operaciones: suma, resta, multiplicacion, division, raiz");

        boolean continuar = true;

        while (continuar) {
            System.out.print("\nIngrese la operación: ");
            String operacion = sc.nextLine().toLowerCase();

            double num1 = 0, num2 = 0;

            if (!operacion.equals("raiz")) {
                System.out.print("Ingrese el primer número: ");
                String entrada1 = sc.nextLine();
                if (!validador.esNumero(entrada1)) {
                    System.out.println("Error: el valor ingresado no es numérico.");
                    continue;
                }
                num1 = Double.parseDouble(entrada1);

                System.out.print("Ingrese el segundo número: ");
                String entrada2 = sc.nextLine();
                if (!validador.esNumero(entrada2)) {
                    System.out.println("Error: el valor ingresado no es numérico.");
                    continue;
                }
                num2 = Double.parseDouble(entrada2);
            } else {
                System.out.print("Ingrese el número: ");
                String entrada1 = sc.nextLine();
                if (!validador.esNumero(entrada1)) {
                    System.out.println("Error: el valor ingresado no es numérico.");
                    continue;
                }
                num1 = Double.parseDouble(entrada1);
            }

            try {
                double resultado = 0;
                switch (operacion) {
                    case "suma":
                        resultado = calc.sumar(num1, num2);
                        break;
                    case "resta":
                        resultado = calc.restar(num1, num2);
                        break;
                    case "multiplicacion":
                        resultado = calc.multiplicar(num1, num2);
                        break;
                    case "division":
                        resultado = calc.dividir(num1, num2);
                        break;
                    case "raiz":
                        resultado = calc.raizCuadrada(num1);
                        break;
                    default:
                        System.out.println("Operación no válida.");
                        continue;
                }
                System.out.println("Resultado: " + resultado);
            } catch (ArithmeticException e) {
                System.out.println("Error: " + e.getMessage());
            }

            // Preguntar si quiere continuar
            System.out.print("\n¿Desea realizar otra operación? (s/n): ");
            String respuesta = sc.nextLine().trim().toLowerCase();
            if (!respuesta.equals("s")) {
                continuar = false;
                System.out.println("Gracias por usar la calculadora. ¡Adiós!");
            }
        }

        sc.close();
    }
}
